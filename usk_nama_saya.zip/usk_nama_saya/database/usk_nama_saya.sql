-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Mar 2021 pada 05.24
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `usk_nama_saya`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `usk_kategoriproduk`
--

CREATE TABLE `usk_kategoriproduk` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `usk_produk`
--

CREATE TABLE `usk_produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int(30) NOT NULL,
  `id_kategori` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `usk_transaksi`
--

CREATE TABLE `usk_transaksi` (
  `id_transaksi` int(30) NOT NULL,
  `id_produk` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `total_bayar` int(30) NOT NULL,
  `tgl_transaksi` datetime(6) NOT NULL,
  `id_user` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `usk_user`
--

CREATE TABLE `usk_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `usk_user`
--

INSERT INTO `usk_user` (`id_user`, `nama_user`, `username`, `password`) VALUES
(1, 'Joni Hermansyah', 'joni', 'joni123'),
(2, 'Ardia Sinaga', 'ardia', 'ardia123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `usk_kategoriproduk`
--
ALTER TABLE `usk_kategoriproduk`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `usk_produk`
--
ALTER TABLE `usk_produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indeks untuk tabel `usk_transaksi`
--
ALTER TABLE `usk_transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_barang` (`id_produk`),
  ADD KEY `id_pengguna` (`id_user`);

--
-- Indeks untuk tabel `usk_user`
--
ALTER TABLE `usk_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `usk_kategoriproduk`
--
ALTER TABLE `usk_kategoriproduk`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `usk_produk`
--
ALTER TABLE `usk_produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `usk_transaksi`
--
ALTER TABLE `usk_transaksi`
  MODIFY `id_transaksi` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `usk_user`
--
ALTER TABLE `usk_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `usk_produk`
--
ALTER TABLE `usk_produk`
  ADD CONSTRAINT `usk_produk_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `usk_kategoriproduk` (`id_kategori`);

--
-- Ketidakleluasaan untuk tabel `usk_transaksi`
--
ALTER TABLE `usk_transaksi`
  ADD CONSTRAINT `usk_transaksi_ibfk_1` FOREIGN KEY (`id_produk`) REFERENCES `usk_produk` (`id_produk`),
  ADD CONSTRAINT `usk_transaksi_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `usk_user` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
