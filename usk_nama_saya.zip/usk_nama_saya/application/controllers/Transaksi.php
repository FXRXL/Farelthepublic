<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('transaksi_model', 'transaksi');
        $this->load->model('produk_model', 'produk');
        $this->load->model('kategori_model', 'kategori');
        $this->load->model('user_model', 'user');
        if ( !$this->session->userdata('id_user') ) {
            $this->session->set_flashdata('error', 'Anda Belum Login!');
            redirect(site_url('login'));
        }
    }

	public function index()
	{
        $data = [
            'title'     => 'Transaksi',
            'content'   => 'transaksi/index',
            'transaksi' => $this->transaksi->index()
        ];
        
		$this->load->view('layout/app', $data);
	}

	public function tambah()
	{
        $data = [
            'title'     => 'Transaksi',
            'content'   => 'transaksi/tambah',
            'produk'    => $this->produk->index(),
            'kategori'  => $this->kategori->index(),
        ];
		$this->load->view('layout/app', $data);
	}

    public function insert()
    {
        $data = [
            'id_produk'     => $this->input->post('produk_id'),
            'quantity'      => $this->input->post('quantity'),
            'total_bayar'   => $this->input->post('total_bayar'),
            'tgl_transaksi' => date('Y-m-d H:i:s'),
            'id_user'   	=> $this->session->userdata('id_user')
        ];

        $this->transaksi->tambah($data);

        $this->session->set_flashdata('success', 'Data Transaksi Berhasil Di Tambahkan');
        redirect(site_url('transaksi'));
    }

    public function get_produk()
    {
        echo json_encode($this->produk->kategori($this->input->post('id_kategori')));
    }

    public function get_harga()
    {
        echo json_encode($this->produk->harga($this->input->post('id_produk')));
    }
}
