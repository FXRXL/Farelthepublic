<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('user_model', 'user');
    }

    // Menampilkan form login
	public function index()
	{
		$this->load->view('login/index');
	}

	// Check login
	public function login()
	{
		$login = $this->user->login($this->input->post('username'), $this->input->post('password'));
		if ( !empty($login) ) {
			$this->session->set_userdata('id_user', $login->id_user);
			$this->session->set_userdata('nama_user', $login->nama_user);
			$this->session->set_userdata('username', $login->username);
			redirect(site_url('beranda'));
		} else {
			$this->session->set_flashdata('error', 'Username atau Password Salah!!');
			redirect(site_url('login'));
		}
	}

	public function logout()
	{
		$this->session->unset_userdata(['id_user', 'username', 'nama_user']);
		$this->session->set_flashdata('success', 'Anda Berhasil Logout');
		redirect(site_url('login'));
	}
}
