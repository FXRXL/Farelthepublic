<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi_model extends CI_Model {

    private $table = 'usk_transaksi';

	public function index()
	{
        $this->db->select('usk_transaksi.id_transaksi, tgl_transaksi, nama_produk, quantity, total_bayar, nama_user');
        $this->db->join('usk_user', 'usk_user.id_user = usk_transaksi.id_user', 'left');
        $this->db->join('usk_produk', 'usk_produk.id_produk = usk_transaksi.id_produk', 'left');
        return $this->db->get($this->table)->result();
	}

    public function tambah($data)
    {
        $this->db->insert($this->table, $data);
    }
}
