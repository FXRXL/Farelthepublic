<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    private $table = 'usk_user';

    // Mengambil Semua Data
	public function index()
	{
        return $this->db->get($this->table)->result();
	}

	// cek user login
    public function login($username, $password)
    {
        return $this->db->get_where($this->table, ['username' => $username, 'password' => $password])->row();
    }
}
