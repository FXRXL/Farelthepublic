<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori_model extends CI_Model {

    private $table = 'usk_kategoriproduk';

	public function index()
	{
        return $this->db->get($this->table)->result();
	}
}
