<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk_model extends CI_Model {

    private $table = 'usk_produk';

	public function index()
	{
        return $this->db->get($this->table)->result();
	}

	public function kategori($id_kategori)
	{
		return $this->db->get_where($this->table, ['id_kategori'	=> $id_kategori])->result();
	}
	
	public function harga($id)
	{
		return $this->db->get_where($this->table, ['id_produk' => $id])->row();
	}
}
