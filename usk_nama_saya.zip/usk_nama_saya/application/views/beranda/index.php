<style>
    footer {
        position: absolute;
        bottom: 20px;
        left: 45%;
    }
</style>
<div class="row">
    <div class="col-12 mt-5 text-center">
        <h2>Selamat Datang di Melu.link Store</h2>
    </div>
</div>