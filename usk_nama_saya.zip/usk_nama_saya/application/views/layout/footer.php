        <footer class="row">
            <div class="col-12 text-center">
                <small>USK 2021 - Nama Saya</small>
            </div>
        </footer>
    </div>

    <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>
    <script>
        $('#kategori_id').on('change', function (e) {
            $.ajax({
                type: "POST",
                url: "<?= site_url('transaksi/get_produk') ?>",
                data: {id_kategori: $(this).val()},
                success: function (response) {
                    let data = JSON.parse(response)
                    let html = `<option value="">Pilih Produk</option>`
                    $.each(data, function (index, value) {
                        html += `<option value="${ value.id_produk }">${ value.nama_produk }</option>`
                    })
                    $('#produk_id').html(html)
                }
            })
        })
        
        $('#produk_id').on('change', function (e) {
            $.ajax({
                type: "POST",
                url: "<?= site_url('transaksi/get_harga') ?>",
                data: {id_produk: $(this).val()},
                success: function (response) {
                    let data = JSON.parse(response)
                    $('#harga_produk').val(data.harga_produk)
                }
            })
        })

        $('#btnHitung').on('click', function (e) {
            let hargaBarang = $('#harga_produk').val()
            let diskon = 0
            let total = ($('#quantity').val() * hargaBarang)
            let total_bayar = total
            if (total > 2000000) {
                diskon = 55000
                total_bayar = total - diskon
                $('#diskon').val(diskon)
            }
            $('#jumlah_harga').val(total)
            $('#total_bayar').val(total_bayar)  
        })
    </script>
</body>
</html>