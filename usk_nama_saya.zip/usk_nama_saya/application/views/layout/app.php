<?php
require_once 'header.php';
$this->load->view($content);
require_once 'footer.php';