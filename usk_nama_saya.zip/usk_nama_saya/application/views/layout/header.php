<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css') ?>">
    <style>
        /*.container:nth-child(2) {
            border: 1px solid black;
            height: 83vh;
        }*/

        /*footer {
            position: absolute;
            bottom: 20px;
            left: 45%;
        }*/
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-md navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">MELU.LINK STORE</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navBAR" aria-controls="navBAR" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navBAR">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('beranda') ?>">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Barang</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('transaksi') ?>">Transaksi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Laporan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('login/logout') ?>">Keluar</a>
                </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-3">