<div class="row">
    <div class="col-12">
        <?php if( $this->session->flashdata('success') ) : ?>
            <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
        <?php endif ?>
        <a href="<?= site_url('transaksi/tambah') ?>" class="btn btn-primary my-2">Tambah Transaksi</a>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <tr>
                    <th>NO</th>
                    <th>ID Transaksi</th>
                    <th>Tanggal Transaksi</th>
                    <th>Nama Produk</th>
                    <th>Quantity</th>
                    <th>Total Bayar</th>
                    <th>Nama Kasir</th>
                </tr>
                <?php $no = 1; ?>
                <?php foreach($transaksi as $row) : ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $row->id_transaksi ?></td>
                    <td><?= $row->tgl_transaksi ?></td>
                    <td><?= $row->nama_produk ?></td>
                    <td><?= $row->quantity ?></td>
                    <td><?= $row->total_bayar ?></td>
                    <td><?= $row->nama_user ?></td>
                </tr>
                <?php $no++ ?>
                <?php endforeach ?>
            </table>
        </div>
    </div>
</div>