<div class="row py-5">
    <div class="col-12">
        <form method="POST" action="<?= site_url('transaksi/insert') ?>">
            <div class="form-group row">
              <label for="kategori_id" class="col-sm-2 control-label">Kategori</label>
              <div class="col-sm-10">
                <select name="kategori_id" id="kategori_id" class="form-control">
                    <option value="">Pilih Kategori</option>
                    <?php foreach($kategori as $option) : ?>
                        <option value="<?= $option->id_kategori ?>"><?= $option->nama_kategori ?></option>
                    <?php endforeach ?>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label for="produk_id" class="col-sm-2 control-label">Nama Produk</label>
              <div class="col-sm-10">
                <select name="produk_id" id="produk_id" class="form-control">
                    
                </select>
              </div>
            </div>
            <div class="form-group row">
                <label for="harga_produk" class="col-sm-2">Harga Produk</label>
                <div class="col-sm-10">
                  <input type="number" class="form-control" id="harga_produk" name="harga_produk" placeholder="Masukan Harga Produk">
                </div>
            </div>
            <div class="form-group row">
                <label for="quantity" class="col-sm-2">Quantity</label>
                <div class="col-sm-10">
                  <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Masukan Quantity">
                </div>
            </div>
            <div class="form-group row">
                <label for="qty" class="col-sm-2"></label>
                <div class="col-sm-10">
                  <button type="button" class="btn btn-primary mt-2 mb-3" id="btnHitung">Hitung</button>
                </div>
            </div>
            <div class="form-group row">
                <label for="jumlah_harga" class="col-sm-2">Jumlah Harga</label>
                <div class="col-sm-10">
                  <input type="number" class="form-control" id="jumlah_harga" placeholder="Masukan Junlah Harga">
                </div>
            </div>
            <div class="form-group row">
                <label for="diskon" class="col-sm-2">Diskon</label>
                <div class="col-sm-10">
                  <input type="number" class="form-control" id="diskon" placeholder="Masukan Diskon" readonly>
                </div>
            </div>
            <div class="form-group row">
                <label for="total_bayar" class="col-sm-2">Total Bayar</label>
                <div class="col-sm-10">
                  <input type="number" class="form-control" id="total_bayar" name="total_bayar" placeholder="Masukan Total Bayar">
                </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12 text-right">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('transaksi') ?>" type="submit" class="btn btn-danger">Batal</a>
              </div>
            </div>
        </form>
    </div>
</div>