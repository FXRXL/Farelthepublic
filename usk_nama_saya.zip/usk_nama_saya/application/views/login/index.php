<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css') ?>">
</head>
<body>
    
    <div class="container py-5">
        <div class="row mt-5">
            <div class="col-8 mx-auto">
                <h2 class="text-center mb-5">LOGIN Melu.Link</h2>
                <?php if( $this->session->flashdata('error') ) : ?>
                    <script type="text/javascript">
                        alert("<?= $this->session->flashdata('error') ?>")
                    </script>
                <?php endif ?>
                <?php if( $this->session->flashdata('success') ) : ?>
                    <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
                <?php endif ?>
                <form method="POST" action="<?= site_url('login/login') ?>">
                    <div class="form-group row">
                      <label for="username" class="col-sm-2">Username</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="username" name="username" placeholder="Masukan Username">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="password" class="col-sm-2 control-label">Password</label>
                      <div class="col-sm-10">
                        <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-12 text-right">
                        <button type="submit" class="btn btn-primary">Masuk</button>
                      </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.js') ?>"></script>
    <script>
</body>
</html>